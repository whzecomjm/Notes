1. Copy "InftyReg.dll" file to install folder
2. Fill out "Serial No." field with 111111-222222
3. Click "Online authentication" button
4. The program will be closed with the error message
5. To register the program use the License key: 11111111112222222222